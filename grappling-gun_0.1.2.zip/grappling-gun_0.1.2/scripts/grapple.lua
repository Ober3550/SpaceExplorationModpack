Grapple = {}

-- constants
Grapple.range = 24
Grapple.throw_speed = 0.6
Grapple.pull_speed = 0.4

function Grapple.destroy(tick_task)
  tick_task.valid = false
  if tick_task.projectile and tick_task.projectile.valid then
    tick_task.projectile.destroy()
  end
end

function Grapple.on_trigger_created_entity(event)
  if event.entity.name == "grappling-gun-trigger" then

    if global.tick_tasks then
      for _, tick_task in pairs(global.tick_tasks) do
        if tick_task.type == "grappling-gun" and tick_task.character == event.source then
          Grapple.destroy(tick_task)
        end
      end
    end

    local tick_task = new_tick_task("grappling-gun")
    tick_task.surface = event.entity.surface
    tick_task.character = event.source
    tick_task.instigator_force = event.source.force

    local vector = util.vectors_delta(event.source.position, event.entity.position)
    if Util.vector_length(vector) > Grapple.range then
      vector = Util.vector_set_length(vector, Grapple.range)
    end
    local target_position = Util.vectors_add(event.source.position, vector)
    local safe_position = tick_task.surface.find_non_colliding_position (
      "grappling-gun-player-collision", target_position, Grapple.range / 4, 1, true
    )
    tick_task.target_position = safe_position or target_position
    tick_task.safe_position = safe_position -- may be nil

    tick_task.projectile = tick_task.surface.create_entity{
      name = "grappling-gun-projectile",
      position = event.source.position,
      target = Util.vectors_add(tick_task.target_position, vector), -- aim further away
      speed = 0,
    }
    rendering.draw_line{
      color = {r=50,g=50,b=50,a=1},
      width = 2,
      gap_length = 0.1,
      dash_length = 0.1,
      from = tick_task.projectile,
      from_offset = {0, -1},
      to = tick_task.character,
      to_offset = {0, -1},
      surface = tick_task.projectile.surface
    }
    rendering.draw_line{
      color = {r=0,g=0,b=0,a=1},
      width = 1,
      from = tick_task.projectile,
      from_offset = {0, -1},
      to = tick_task.character,
      to_offset = {0, -1},
      surface = tick_task.projectile.surface
    }
  end
end
Event.addListener(defines.events.on_trigger_created_entity, Grapple.on_trigger_created_entity)

function Grapple.tick_task_grappling_gun(tick_task)
  if tick_task.projectile and tick_task.projectile.valid and tick_task.character and tick_task.character.valid
    and tick_task.projectile.surface == tick_task.character.surface then

    if tick_task.pull then
      tick_task.character.teleport(Util.move_to(tick_task.character.position, tick_task.safe_position, Grapple.pull_speed))
      if Util.vectors_delta_length(tick_task.character.position, tick_task.safe_position) < 0.1 then
        Grapple.destroy(tick_task)
      end
    else
      tick_task.projectile.teleport(Util.move_to(tick_task.projectile.position, tick_task.target_position, Grapple.throw_speed))
      if Util.vectors_delta_length(tick_task.projectile.position, tick_task.target_position) < 0.01 then
        if tick_task.safe_position then
          tick_task.pull = true
        else
          Grapple.destroy(tick_task)
        end
      end
    end

  else
    Grapple.destroy(tick_task)
  end

end

return Grapple
