local data_util = require("data_util")

data:extend({
  {
    type = "technology",
    name = data_util.mod_prefix .. "grappling-gun",
    effects = {
     { type = "unlock-recipe",  recipe = data_util.mod_prefix .. "grappling-gun" },
     { type = "unlock-recipe",  recipe = data_util.mod_prefix .. "grappling-gun-ammo" },
    },
    icon = "__grappling-gun__/graphics/technology/grappling-gun.png",
    icon_size = 128,
    order = "e-g",
    prerequisites = {
      "rocket-fuel",
      "low-density-structure",
    },
    unit = {
     count = 100,
     time = 10,
     ingredients = {
       { "automation-science-pack", 1 },
       { "logistic-science-pack", 1 },
       { "chemical-science-pack", 1 },
     }
    },
  },
})
