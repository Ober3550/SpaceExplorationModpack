data.raw["gui-style"]["default"]["aai_signal_transmission_sprite_button"] = {
    type = "button_style",
    parent = "button",
    width = 32,
    height = 32,
    top_padding = 1,
    right_padding = 1,
    bottom_padding = 1,
    left_padding = 1,
}
data.raw["gui-style"]["default"]["aai_signal_transmission_sprite_button_small"] = {
    type = "button_style",
    parent = "aai_signal_transmission_sprite_button",
    width = 20,
    height = 20,
}
