local multiplier = 						settings.startup["nuclear-ups-multiplier"].value

function multiply_number_unit(property, mult)
	value = {}
	value[1] = string.match(property, "%d+")
	if string.match(property, "%d+%.%d+") then		-- catch floats
		value[1] = string.match(property, "%d+%.%d+")
	end
	value[2] = string.match(property, "%a+")
	if value[2] == nil then
		return value[1] * mult
	else
		return ((value[1] * mult) .. value[2])
	end
end

function multiply_ingredient (ingredient, mult)
	if ingredient[2] ~= nil then
		ingredient[2] = math.floor(ingredient[2] * mult + 0.5)
	elseif ingredient.amount ~= nil then
		ingredient.amount = math.floor(ingredient.amount * mult + 0.5)
	end
end

function multiply_ingredients(item, factor)
	if data.raw.recipe[item.name] then
		local recipe_tiers = {	data.raw.recipe[item.name],
								data.raw.recipe[item.name].normal,
								data.raw.recipe[item.name].expensive
								}
		for _, recipe in pairs(recipe_tiers) do
			if recipe and recipe.energy_required then
				recipe.energy_required = recipe.energy_required * factor
			end
			if recipe and recipe.ingredients then
				for _, ingredient in pairs(recipe.ingredients) do
					multiply_ingredient(ingredient, factor)
				end
			end
		end
	end
end

if multiplier > 1 then
	for _,reactor in pairs(data.raw["reactor"]) do
		if reactor.energy_source and reactor.energy_source.effectivity then
			reactor.energy_source.effectivity = reactor.energy_source.effectivity / multiplier
		end
		
		multiply_ingredients(reactor, multiplier)
	end
	
	for _,gen in pairs(data.raw["generator"]) do
		if gen.name and string.match(gen.name, "turbine") then
			gen.effectivity = gen.effectivity * multiplier
		end
	end
end

if data.raw["mining-drill"]["geothermal-well"] then
	--data.raw["mining-drill"]["geothermal-well"].mining_speed = data.raw["mining-drill"]["geothermal-well"].mining_speed/multiplier
	for _,recipe in pairs(data.raw.recipe) do
		if string.match(recipe.name, "geothermal%-exchange%-2") then
			if recipe.energy_required then
				recipe.energy_required = recipe.energy_required * multiplier
			else
				recipe.energy_required = multiplier
			end
			for _,ing in pairs (recipe.ingredients) do
				if ing.name == "geothermal-water" then
					ing.amount = ing.amount * multiplier
				end
			end
		end
	end
end