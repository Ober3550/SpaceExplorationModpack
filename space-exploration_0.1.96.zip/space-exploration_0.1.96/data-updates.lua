
require("prototypes/phase-multi/no-recycle")

require("prototypes/phase-2/recipe-update")
