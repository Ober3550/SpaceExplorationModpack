local Migrate = {}

function Migrate.migrations()
  if not global.version then global.version = 0 end

  if global.version < version then
    if global.version < 000138 then Migrate.v0_1_38() end
    if global.version < 0001065 then Migrate.v0_1_65() end
    if global.version < 0001086 then Migrate.v0_1_86() end
    if global.version < 0001089 then Migrate.v0_1_89() end
    if global.version < 0001096 then Migrate.v0_1_96() end
  end
  global.version = version
end

function Migrate.v0_1_38_zone(zone)
  zone.core_miners = nil
  local surface = Zone.get_make_surface(zone)
  for _, miner in pairs(surface.find_entities_filtered{name = mod_prefix.."core-miner"}) do
    Coreminer.on_entity_created({entity = miner})
  end
end

function Migrate.v0_1_38 ()
  if global.universe then

    for _, star in pairs(global.universe.stars) do
      for _, planet in pairs(star.children) do
        if planet.core_miners then
          Migrate.v0_1_38_zone(planet)
        end
        if planet.children then -- could be an asteroid-belt
          for _, moon in pairs(planet.children) do
            if moon.core_miners then
              Migrate.v0_1_38_zone(moon)
            end
          end
        end
      end
    end
  end

end

function Migrate.v0_1_65 ()
  if global.universe then
    for _, zone in pairs(global.zone_index) do
      if zone.controls and zone.controls["enemy"] then
        zone.controls["enemy-base"] = zone.controls["enemy"]
        zone.controls["enemy"] = nil
        if zone.name ~= "Nauvis" then
          local surface = Zone.get_surface(zone)
          if surface then
            local map_gen_settings = surface.map_gen_settings
            map_gen_settings.autoplace_controls["enemy-base"].size = zone.controls["enemy-base"].size
            map_gen_settings.autoplace_controls["enemy-base"].frequency = zone.controls["enemy-base"].frequency
            surface.map_gen_settings = map_gen_settings
            if zone.controls["enemy-base"].size == 0  then
              local enemies = surface.find_entities_filtered{force={"enemy"}}
              for _, enemy in pairs(enemies) do
                enemy.destroy()
              end
            end
          end
        end
      end
    end
  end

end

function Migrate.v0_1_86()
  if global.universe then
    for _, zone in pairs(global.zone_index) do
      if Zone.is_solid(zone) then
        -- nauvis is 25000
        if zone.inflated and not zone.ticks_per_day then
          zone.ticks_per_day = 25000 -- nauvis
          if zone.name ~= "Nauvis" then
            if math.random() < 0.5 then
              zone.ticks_per_day = 60*60 + math.random(60*60*59) -- 1 - 60 minutes
            else
              zone.ticks_per_day = 60*60 + math.random(60*60*19) -- 1 - 20 minutes
            end
            local surface = Zone.get_surface(zone)
            if surface then
              surface.ticks_per_day = zone.ticks_per_day
            end
          end
        end
      end
    end
  end
end

function Migrate.v0_1_89()
  --global.rocket_landing_pads = global.rocket_landing_pads or {}
  for _, struct in pairs(global.rocket_landing_pads) do
    Landingpad.rename(struct, struct.name)
  end
end

function Migrate.v0_1_96()
  if global.universe then
    for _, zone in pairs(global.zone_index) do
      if Zone.is_space(zone) then
        local surface = Zone.get_surface(zone)
        if surface then
          local entities = surface.find_entities_filtered{type="offshore-pump"}
          for _, entity in pairs(entities) do
            entity.destroy()
          end
        end
      end
    end
  end
end

return Migrate
