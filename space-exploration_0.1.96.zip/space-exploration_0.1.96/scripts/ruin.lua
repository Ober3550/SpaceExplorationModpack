local Ruin = {}

Ruin.ruins = {}

Ruin.ruins["satellite"] = require("ruins/satellite.lua")
--/c remote.call("space-exploration", "build_ruin", {ruin_name = "satellite", surface_index = game.player.surface.index, position = game.player.position})

-- Add more ruins here
--Ruin.ruins["my-ruin"] = require("ruins/my-ruin.lua")
-- test with
--/c remote.call("space-exploration", "build_ruin", {ruin_name = "my-ruin", surface_index = game.player.surface.index, position = game.player.position})

function Ruin.build(data)
  if not (data.ruin_name and data.surface_index and data.position) then return end
  local ruin_name = data.ruin_name
  local ruin = Ruin.ruins[ruin_name]
  if not ruin then return end

  local ruin_position = data.position
  ruin_position.x = math.floor(ruin_position.x)
  ruin_position.y = math.floor(ruin_position.y)

  local surface = game.surfaces[data.surface_index]

  surface.request_to_generate_chunks(ruin_position, 2)
  surface.force_generate_chunk_requests() -- must be generated to place

  local tiles = {}
  for tile_name, positions in pairs(ruin.tiles) do
    for _, position in pairs(positions) do
      table.insert(tiles, {name = tile_name,
      position = {
        x = ruin_position.x + position[1] - ruin.center[1],
        y = ruin_position.y + position[2] - ruin.center[2]}})
    end
  end
  surface.set_tiles(tiles, true)

  for entity_name, set in pairs(ruin.entities) do
    for _, entity_data in pairs(set) do
      if type(entity_data.x) == "number" or type(entity_data[1]) then
        local entity_relative_position = {
          x = 0 + (entity_data.x or entity_data[1]),
          y = 0 + (entity_data.y or entity_data[2])
        }
        local entity_position = {
          x = ruin_position.x + entity_relative_position.x - ruin.center[1],
          y = ruin_position.y + entity_relative_position.y - ruin.center[2]
        }
        local force_name = entity_data.force_name or "capture"
        if force_name == "capture" then force_name = "neutral" end
        local entity = surface.create_entity{
          name = entity_name,
          force = force_name,
          position = entity_position,
          direction = entity_data.direction
        }
        if entity_data.stacks then
          for _, stack in pairs(entity_data.stacks) do
            entity.insert{name = stack.name, count = stack.count}
          end
        end
      end
    end
  end
end

return Ruin
