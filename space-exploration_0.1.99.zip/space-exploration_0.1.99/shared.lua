local Shared = {}

Shared.resources_with_shared_controls = {
 "lithia-water", --uses ground-water
}

return Shared
